package com.ljustlifeless.robloxaccountmanagement

/** Small, deterministic validation for catalog usernames. This does not contact Roblox. */
object AccountInputValidator {
    /** Returns a trimmed username, or null when it is empty. */
    fun normalizeUsername(value: String): String? = value.trim().takeIf { it.isNotEmpty() }
}
