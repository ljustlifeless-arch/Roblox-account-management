package com.ljustlifeless.robloxaccountmanagement.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "accounts")
data class Account(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val username: String,
    val displayName: String = "",
    val branch: String = "Не распределён",
    val role: String = "Участник",
    val accessStatus: String = "Не проверен",
    val recoveryStatus: String = "Не проверено",
    val gamePurpose: String = "",
    val notes: String = "",
    val lastChecked: Long = System.currentTimeMillis(),
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "account_events")
data class AccountEvent(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val accountId: Long,
    val timestamp: Long = System.currentTimeMillis(),
    val eventType: String,
    val details: String
)
