package com.ljustlifeless.robloxaccountmanagement.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface AccountDao {
    @Query("SELECT * FROM accounts ORDER BY username COLLATE NOCASE ASC")
    fun observeAll(): Flow<List<Account>>

    @Query("""SELECT * FROM accounts
        WHERE username LIKE '%' || :query || '%'
        OR displayName LIKE '%' || :query || '%'
        OR branch LIKE '%' || :query || '%'
        OR notes LIKE '%' || :query || '%'
        ORDER BY username COLLATE NOCASE ASC""")
    fun search(query: String): Flow<List<Account>>

    @Query("SELECT * FROM accounts WHERE id = :id LIMIT 1")
    suspend fun getById(id: Long): Account?

    @Insert
    suspend fun insert(account: Account): Long

    @Update
    suspend fun update(account: Account)

    @Query("DELETE FROM accounts WHERE id = :id")
    suspend fun delete(id: Long)

    @Query("SELECT * FROM account_events WHERE accountId = :accountId ORDER BY timestamp DESC")
    fun eventsFor(accountId: Long): Flow<List<AccountEvent>>

    @Insert
    suspend fun addEvent(event: AccountEvent)

    @Query("SELECT COUNT(*) FROM accounts")
    fun count(): Flow<Int>

    @Query("SELECT COUNT(*) FROM accounts")
    suspend fun countNow(): Int

    @Query("SELECT * FROM accounts ORDER BY username COLLATE NOCASE ASC")
    suspend fun allForExport(): List<Account>

    @Query("SELECT COUNT(*) FROM accounts WHERE accessStatus = 'Доступ есть'")
    fun accessibleCount(): Flow<Int>
}
