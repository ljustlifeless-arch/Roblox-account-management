package com.ljustlifeless.robloxaccountmanagement

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.lifecycleScope
import com.ljustlifeless.robloxaccountmanagement.data.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {
    private val dao by lazy { AppDatabase.get(this).accountDao() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = androidx.compose.ui.graphics.Color(0xFF9EB8FF),
                    secondary = androidx.compose.ui.graphics.Color(0xFFB9C7E8),
                    background = androidx.compose.ui.graphics.Color(0xFF101318),
                    surface = androidx.compose.ui.graphics.Color(0xFF191D24)
                )
            ) {
                AccountApp(dao = dao, onExport = { exportCsv() })
            }
        }
    }

    private fun exportCsv() {
        lifecycleScope.launch {
            val rows = dao.allForExport()
            val header = "username,display_name,branch,role,access_status,recovery_status,game_purpose,notes,last_checked"
            fun esc(s: String) = "\"" + s.replace("\"", "\"\"").replace("\n", " ") + "\""
            val body = rows.joinToString("\n") {
                listOf(it.username, it.displayName, it.branch, it.role, it.accessStatus,
                    it.recoveryStatus, it.gamePurpose, it.notes,
                    SimpleDateFormat("yyyy-MM-dd", Locale.ROOT).format(Date(it.lastChecked)))
                    .joinToString(",") { value -> esc(value) }
            }
            val send = Intent(Intent.ACTION_SEND).apply {
                type = "text/csv"
                putExtra(Intent.EXTRA_SUBJECT, "Roblox Account Management — CSV export")
                putExtra(Intent.EXTRA_TEXT, header + "\n" + body)
            }
            startActivity(Intent.createChooser(send, "Экспорт каталога"))
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AccountApp(dao: AccountDao, onExport: () -> Unit) {
    val scope = rememberCoroutineScope()
    var query by remember { mutableStateOf("") }
    var showEditor by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<Account?>(null) }
    var selected by remember { mutableStateOf<Account?>(null) }
    var showAbout by remember { mutableStateOf(false) }
    var showLimitNotice by remember { mutableStateOf(false) }
    val accounts by dao.search(query).collectAsStateWithLifecycle(initialValue = emptyList())
    val total by dao.count().collectAsStateWithLifecycle(initialValue = 0)
    val accessible by dao.accessibleCount().collectAsStateWithLifecycle(initialValue = 0)

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("ACCOUNT MANAGEMENT", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Text("Локальный каталог Roblox", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                },
                actions = {
                    IconButton(onClick = onExport) { Icon(Icons.Default.Download, contentDescription = "Экспорт CSV") }
                }
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { if (total < 100) { editing = null; showEditor = true } else { showLimitNotice = true } },
                icon = { Icon(Icons.Default.Add, contentDescription = null) },
                text = { Text("Добавить") }
            )
        }
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                StatCard("Всего", total.toString(), Modifier.weight(1f))
                StatCard("Доступ есть", accessible.toString(), Modifier.weight(1f))
                StatCard("В списке", accounts.size.toString(), Modifier.weight(1f))
            }
            Spacer(Modifier.height(14.dp))
            OutlinedTextField(
                value = query, onValueChange = { query = it },
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("Поиск по имени, ветви, заметкам") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                singleLine = true,
                shape = RoundedCornerShape(16.dp)
            )
            Spacer(Modifier.height(12.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Groups, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                Spacer(Modifier.width(8.dp))
                Text("Каталог аккаунтов", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.weight(1f))
                Text("${accounts.size}", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Spacer(Modifier.height(8.dp))
            if (accounts.isEmpty()) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(Modifier.padding(22.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(if (query.isBlank()) "Каталог пока пуст" else "Ничего не найдено", style = MaterialTheme.typography.titleMedium)
                        Text(
                            if (query.isBlank()) "Добавь первый аккаунт или создай демонстрационный набор для проверки приложения."
                            else "Попробуй изменить запрос или искать по части имени.",
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        if (query.isBlank()) {
                            OutlinedButton(onClick = {
                                scope.launch {
                                    val sample = listOf(
                                        Account(username = "DemoAccount001", branch = "NULL", role = "Глава", notes = "Пример записи — замени или удали."),
                                        Account(username = "DemoAccount002", branch = "NULL", role = "Заместитель"),
                                        Account(username = "DemoAccount003", branch = "Не распределён", role = "Участник")
                                    )
                                    sample.forEach { dao.insert(it) }
                                }
                            }) { Text("Добавить примеры") }
                        }
                    }
                }
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(bottom = 100.dp),
                    verticalArrangement = Arrangement.spacedBy(9.dp)
                ) {
                    items(accounts, key = { it.id }) { account ->
                        AccountCard(
                            account = account,
                            onClick = { selected = account },
                            onEdit = { editing = account; showEditor = true }
                        )
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
            TextButton(onClick = { showAbout = true }, modifier = Modifier.align(Alignment.Start)) {
                Text("О приложении и безопасности")
            }
        }
    }

    if (showEditor) {
        AccountEditor(
            initial = editing,
            onDismiss = { showEditor = false },
            onSave = { account ->
                scope.launch {
                    if (account.id == 0L && dao.countNow() >= 100) {
                        showLimitNotice = true
                        return@launch
                    }
                    val id = if (account.id == 0L) dao.insert(account) else {
                        dao.update(account)
                        account.id
                    }
                    dao.addEvent(AccountEvent(
                        accountId = id,
                        eventType = if (account.id == 0L) "Создание" else "Изменение",
                        details = "Карточка аккаунта сохранена"
                    ))
                }
                showEditor = false
            }
        )
    }
    selected?.let { account ->
        AccountDetails(
            account = account,
            dao = dao,
            onDismiss = { selected = null },
            onEdit = { selected = null; editing = account; showEditor = true },
            onDelete = {
                scope.launch {
                    dao.addEvent(AccountEvent(accountId = account.id, eventType = "Удаление", details = "Карточка удалена"))
                    dao.delete(account.id)
                }
                selected = null
            }
        )
    }
    if (showLimitNotice) {
        AlertDialog(
            onDismissRequest = { showLimitNotice = false },
            title = { Text("Достигнут лимит") },
            text = { Text("Каталог рассчитан максимум на 100 записей. Удали ненужную запись перед добавлением новой.") },
            confirmButton = { TextButton(onClick = { showLimitNotice = false }) { Text("Понятно") } }
        )
    }

    if (showAbout) {
        AlertDialog(
            onDismissRequest = { showAbout = false },
            title = { Text("О приложении") },
            text = {
                Text("Версия 1.0.0\n\nДанные хранятся локально на этом устройстве. Не сохраняй здесь пароли, cookies, токены или коды восстановления. Эта версия не шифрует базу данных и не подключается к Roblox. Для резервной копии используй экспорт CSV.")
            },
            confirmButton = { TextButton(onClick = { showAbout = false }) { Text("Понятно") }
            }
        )
    }
}

@Composable
private fun StatCard(label: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier, shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.padding(13.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
            Text(value, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun AccountCard(account: Account, onClick: () -> Unit, onEdit: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = MaterialTheme.colorScheme.primary.copy(alpha = .14f),
                modifier = Modifier.size(46.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Text(account.username.take(1).uppercase(), color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                }
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Text(account.username, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                Text("${account.branch} · ${account.role}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    TinyTag(account.accessStatus)
                    TinyTag("Восст.: ${account.recoveryStatus}")
                }
            }
            TextButton(onClick = onEdit) { Text("Изменить") }
        }
    }
}

@Composable
private fun TinyTag(text: String) {
    Surface(shape = RoundedCornerShape(8.dp), color = MaterialTheme.colorScheme.background) {
        Text(text, modifier = Modifier.padding(horizontal = 7.dp, vertical = 4.dp), style = MaterialTheme.typography.labelSmall)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AccountEditor(initial: Account?, onDismiss: () -> Unit, onSave: (Account) -> Unit) {
    var username by remember { mutableStateOf(initial?.username ?: "") }
    var displayName by remember { mutableStateOf(initial?.displayName ?: "") }
    var branch by remember { mutableStateOf(initial?.branch ?: "Не распределён") }
    var role by remember { mutableStateOf(initial?.role ?: "Участник") }
    var access by remember { mutableStateOf(initial?.accessStatus ?: "Не проверен") }
    var recovery by remember { mutableStateOf(initial?.recoveryStatus ?: "Не проверено") }
    var game by remember { mutableStateOf(initial?.gamePurpose ?: "") }
    var notes by remember { mutableStateOf(initial?.notes ?: "") }
    var error by remember { mutableStateOf(false) }
    val branches = listOf("Не распределён", "NULL", "AETHER", "OBLIVION", "ECLIPSE", "GENESIS")
    val roles = listOf("Создатель", "Глава", "Заместитель", "Предок", "Участник")
    val accessOptions = listOf("Не проверен", "Доступ есть", "Нет доступа", "Заблокирован", "Ограничен")
    val recoveryOptions = listOf("Не проверено", "Восстановлен", "В процессе", "Отказано", "Не восстановить")

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial == null) "Новый аккаунт" else "Редактирование") },
        text = {
            Column(
                Modifier.fillMaxWidth().heightIn(max = 540.dp).verticalScroll(androidx.compose.foundation.rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(9.dp)
            ) {
                OutlinedTextField(username, { username = it; error = false }, label = { Text("Username *") }, singleLine = true, isError = error, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(displayName, { displayName = it }, label = { Text("Отображаемое имя") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                DropdownField("Ветвь", branch, branches) { branch = it }
                DropdownField("Роль", role, roles) { role = it }
                DropdownField("Доступ", access, accessOptions) { access = it }
                DropdownField("Восстановление", recovery, recoveryOptions) { recovery = it }
                OutlinedTextField(game, { game = it }, label = { Text("Назначение / игра") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(notes, { notes = it }, label = { Text("Заметки (без секретов)") }, modifier = Modifier.fillMaxWidth(), minLines = 2)
                if (error) Text("Укажи username аккаунта.", color = MaterialTheme.colorScheme.error)
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val normalizedUsername = AccountInputValidator.normalizeUsername(username)
                if (normalizedUsername == null) { error = true; return@TextButton }
                onSave(Account(
                    id = initial?.id ?: 0,
                    username = normalizedUsername,
                    displayName = displayName.trim(),
                    branch = branch,
                    role = role,
                    accessStatus = access,
                    recoveryStatus = recovery,
                    gamePurpose = game.trim(),
                    notes = notes.trim(),
                    createdAt = initial?.createdAt ?: System.currentTimeMillis()
                ))
            }) { Text("Сохранить") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена") } }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun DropdownField(label: String, selected: String, options: List<String>, onSelect: (String) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = !expanded }) {
        OutlinedTextField(
            value = selected, onValueChange = {}, readOnly = true,
            label = { Text(label) },
            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) },
            modifier = Modifier.menuAnchor().fillMaxWidth(),
            singleLine = true
        )
        ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            options.forEach { option ->
                DropdownMenuItem(text = { Text(option) }, onClick = { onSelect(option); expanded = false })
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AccountDetails(
    account: Account,
    dao: AccountDao,
    onDismiss: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    val scope = rememberCoroutineScope()
    val events by dao.eventsFor(account.id).collectAsStateWithLifecycle(initialValue = emptyList())
    var showDeleteConfirm by remember { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(account.username) },
        text = {
            Column(
                Modifier.fillMaxWidth().heightIn(max = 540.dp).padding(top = 4.dp).verticalScroll(androidx.compose.foundation.rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(7.dp)
            ) {
                DetailLine("Отображаемое имя", account.displayName.ifBlank { "—" })
                DetailLine("Ветвь / роль", "${account.branch} / ${account.role}")
                DetailLine("Доступ", account.accessStatus)
                DetailLine("Восстановление", account.recoveryStatus)
                DetailLine("Игра / назначение", account.gamePurpose.ifBlank { "—" })
                DetailLine("Заметки", account.notes.ifBlank { "—" })
                Divider()
                Text("История", fontWeight = FontWeight.SemiBold)
                if (events.isEmpty()) Text("Событий пока нет", color = MaterialTheme.colorScheme.onSurfaceVariant)
                events.take(8).forEach { event ->
                    Text("• ${event.eventType}: ${event.details}", style = MaterialTheme.typography.bodySmall)
                }
                TextButton(onClick = {
                    scope.launch {
                        dao.addEvent(AccountEvent(accountId = account.id, eventType = "Проверка", details = "Статус доступа отмечен как проверенный"))
                        dao.update(account.copy(lastChecked = System.currentTimeMillis()))
                    }
                }) { Text("Записать проверку") }
            }
        },
        confirmButton = { TextButton(onClick = onEdit) { Text("Изменить") } },
        dismissButton = {
            Row {
                TextButton(onClick = { showDeleteConfirm = true }) { Text("Удалить") }
                TextButton(onClick = onDismiss) { Text("Закрыть") }
            }
        }
    )
    if (showDeleteConfirm) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirm = false },
            title = { Text("Удалить аккаунт?") },
            text = { Text("Карточка ${account.username} будет удалена из каталога.") },
            confirmButton = { TextButton(onClick = { showDeleteConfirm = false; onDelete() }) { Text("Удалить") } },
            dismissButton = { TextButton(onClick = { showDeleteConfirm = false }) { Text("Отмена") } }
        )
    }
}

@Composable
private fun DetailLine(label: String, value: String) {
    Column(verticalArrangement = Arrangement.spacedBy(1.dp)) {
        Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, style = MaterialTheme.typography.bodyMedium)
    }
}
