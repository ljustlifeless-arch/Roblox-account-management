package com.ljustlifeless.robloxaccountmanagement

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class AccountInputValidatorTest {
    @Test fun trimsUsername() {
        assertEquals("DemoAccount", AccountInputValidator.normalizeUsername("  DemoAccount  "))
    }

    @Test fun rejectsBlankUsername() {
        assertNull(AccountInputValidator.normalizeUsername("   "))
    }

    @Test fun preservesInternalCharacters() {
        assertEquals("Demo_Account01", AccountInputValidator.normalizeUsername("Demo_Account01"))
    }
}
