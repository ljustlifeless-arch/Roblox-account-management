# Roblox Account Management

Android-first starter project for a local Roblox account catalog.

## Requirements
- Android Studio with Android SDK
- JDK 17
- Minimum Android version: Android 10 (API 29)

## Build
Open this folder in Android Studio and allow Gradle sync to finish.
To build an APK locally: **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

The GitHub Actions workflow `.github/workflows/android-build.yml` can build a debug APK when this project is pushed to GitHub.

## Current starter functionality
- Add account cards with a username
- Search usernames and notes
- Favorite and pin accounts
- Change access status
- Light/dark theme follows the system

This is a working starting point, not the complete specification. Vault encryption, backups, attachments, custom fields, filters, history and import/export still need to be implemented and tested. Do not store passwords, cookies, tokens or recovery codes in this catalog.
