package com.ljustlifeless.robloxaccountmanagement

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.PushPin
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.outlined.PushPin
import androidx.compose.material.icons.outlined.StarBorder
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.unit.dp
import java.util.UUID

private enum class AccessStatus(val label: String) {
    UNKNOWN("Unchecked / unknown"),
    AVAILABLE("Available"),
    LIMITED("Limited / needs check"),
    LOST("Access lost"),
    BLOCKED("Blocked"),
    RECOVERY("Recovery in progress")
}

private data class Account(
    val id: String = UUID.randomUUID().toString(),
    val username: String,
    val note: String = "",
    val status: AccessStatus = AccessStatus.UNKNOWN,
    val favorite: Boolean = false,
    val pinned: Boolean = false
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AccountApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AccountApp() {
    var accounts by remember { mutableStateOf(listOf<Account>()) }
    var search by remember { mutableStateOf("") }
    var showAdd by remember { mutableStateOf(false) }
    var username by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    var selectedStatus by remember { mutableStateOf(AccessStatus.UNKNOWN) }
    var menuAccountId by remember { mutableStateOf<String?>(null) }

    val filtered = accounts
        .filter {
            it.username.contains(search, ignoreCase = true) ||
                it.note.contains(search, ignoreCase = true)
        }
        .sortedWith(compareByDescending<Account> { it.pinned }.thenByDescending { it.favorite }.thenBy { it.username.lowercase() })

    MaterialTheme(
        colorScheme = if (androidx.compose.foundation.isSystemInDarkTheme())
            darkColorScheme(
                primary = androidx.compose.ui.graphics.Color(0xFFB8C7D9),
                background = androidx.compose.ui.graphics.Color(0xFF11151B),
                surface = androidx.compose.ui.graphics.Color(0xFF1B222B)
            )
        else lightColorScheme(
            primary = androidx.compose.ui.graphics.Color(0xFF40566E),
            background = androidx.compose.ui.graphics.Color(0xFFF3F5F8),
            surface = androidx.compose.ui.graphics.Color(0xFFFFFFFF)
        )
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text("Roblox Account Management", fontWeight = FontWeight.SemiBold)
                            Text("${accounts.size} accounts", style = MaterialTheme.typography.labelSmall)
                        }
                    },
                    actions = {
                        IconButton(onClick = { showAdd = true }) {
                            Icon(Icons.Default.Add, contentDescription = "Add account")
                        }
                    }
                )
            },
            floatingActionButton = {
                FloatingActionButton(onClick = { showAdd = true }) {
                    Icon(Icons.Default.Add, contentDescription = "Add account")
                }
            }
        ) { padding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .padding(horizontal = 16.dp)
            ) {
                OutlinedTextField(
                    value = search,
                    onValueChange = { search = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Search username or note") },
                    singleLine = true
                )
                Spacer(Modifier.height(12.dp))
                if (filtered.isEmpty()) {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text(if (accounts.isEmpty()) "No accounts yet. Tap + to add one." else "No matching accounts.")
                    }
                } else {
                    LazyColumn(
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                        contentPadding = PaddingValues(bottom = 88.dp)
                    ) {
                        items(filtered, key = { it.id }) { account ->
                            ElevatedCard(Modifier.fillMaxWidth()) {
                                Column(Modifier.padding(14.dp)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Column(Modifier.weight(1f)) {
                                            Text(account.username, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                                            Text(account.status.label, style = MaterialTheme.typography.bodySmall)
                                        }
                                        IconButton(onClick = {
                                            accounts = accounts.map {
                                                if (it.id == account.id) it.copy(favorite = !it.favorite) else it
                                            }
                                        }) {
                                            Icon(
                                                if (account.favorite) Icons.Filled.Star else Icons.Outlined.StarBorder,
                                                contentDescription = "Toggle favorite"
                                            )
                                        }
                                        IconButton(onClick = {
                                            accounts = accounts.map {
                                                if (it.id == account.id) it.copy(pinned = !it.pinned) else it
                                            }
                                        }) {
                                            Icon(
                                                if (account.pinned) Icons.Filled.PushPin else Icons.Outlined.PushPin,
                                                contentDescription = "Toggle pin"
                                            )
                                        }
                                        Box {
                                            TextButton(onClick = { menuAccountId = account.id }) { Text("⋮") }
                                            DropdownMenu(
                                                expanded = menuAccountId == account.id,
                                                onDismissRequest = { menuAccountId = null }
                                            ) {
                                                AccessStatus.entries.forEach { status ->
                                                    DropdownMenuItem(
                                                        text = { Text(status.label) },
                                                        onClick = {
                                                            accounts = accounts.map {
                                                                if (it.id == account.id) it.copy(status = status) else it
                                                            }
                                                            menuAccountId = null
                                                        }
                                                    )
                                                }
                                                HorizontalDivider()
                                                DropdownMenuItem(
                                                    text = { Text("Delete account") },
                                                    onClick = {
                                                        accounts = accounts.filterNot { it.id == account.id }
                                                        menuAccountId = null
                                                    }
                                                )
                                            }
                                        }
                                    }
                                    if (account.note.isNotBlank()) {
                                        Spacer(Modifier.height(6.dp))
                                        Text(account.note, style = MaterialTheme.typography.bodyMedium)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        if (showAdd) {
            AlertDialog(
                onDismissRequest = { showAdd = false },
                title = { Text("New account") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = username,
                            onValueChange = { username = it },
                            label = { Text("Username (required)") },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.None)
                        )
                        OutlinedTextField(
                            value = note,
                            onValueChange = { note = it },
                            label = { Text("Note (optional)") },
                            minLines = 2
                        )
                    }
                },
                confirmButton = {
                    TextButton(
                        enabled = username.isNotBlank(),
                        onClick = {
                            accounts = accounts + Account(username = username.trim(), note = note.trim())
                            username = ""
                            note = ""
                            showAdd = false
                        }
                    ) { Text("Create") }
                },
                dismissButton = {
                    TextButton(onClick = { showAdd = false }) { Text("Cancel") }
                }
            )
        }
    }
}
